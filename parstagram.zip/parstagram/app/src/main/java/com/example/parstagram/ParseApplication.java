package com.example.parstagram;

import android.app.Application;

import com.parse.Parse;

public class ParseApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("k82UuoxuYCKI2D0EhESDnQZYGYMuP8ceAN89aQyR")
                .clientKey("nmtGJyhvckLLm9qTN4JgCay0PIV0Gd8bpzK2C6Ik")
                .server("https://parseapi.back4app.com")
                .build()
        );
    }
}
